#include "parser.h"

parser::parser(statement *newline)
{

}
