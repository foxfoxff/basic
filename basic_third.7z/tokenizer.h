#ifndef TOKENIZER_H
#define TOKENIZER_H

#include<QList>




#endif // TOKENIZER_H
